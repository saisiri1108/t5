# React + Express Example (minimal)

This repo contains:
- `frontend/` — a minimal React app using Vite as dev server
- `backend/` — an Express server exposing `/api/hello`

Quick start (locally):
1. Install dependencies for backend:
   ```
   cd backend
   npm install
   npm start
   ```
   Backend will run on port 4000.

2. In another terminal start frontend (requires Node + npm):
   ```
   cd frontend
   npm install
   npm run dev
   ```
   Vite dev server typically runs on port 5173. API calls from the frontend fetch `/api/hello` — during development you may need to proxy or run both servers and configure CORS. The backend in this example enables CORS.

Build for production:
1. Build frontend:
   ```
   cd frontend
   npm run build
   ```
   This creates `frontend/dist/`. Then start backend:
   ```
   cd backend
   npm start
   ```
   Backend will serve the built frontend.

Enjoy!
