import React, {useEffect, useState} from 'react'

export default function App(){
  const [message, setMessage] = useState('Loading...')

  useEffect(()=>{
    fetch('/api/hello')
      .then(r=>r.json())
      .then(d=>setMessage(d.message))
      .catch(e=>setMessage('Could not reach backend'))
  },[])

  return (
    <div style={{fontFamily:'Arial, sans-serif', padding:20}}>
      <h1>React + Express Example</h1>
      <p>Backend says: <strong>{message}</strong></p>
      <p>To run: start the backend and frontend (instructions in README).</p>
    </div>
  )
}
