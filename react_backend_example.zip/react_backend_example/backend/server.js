const express = require('express');
const path = require('path');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

// API route
app.get('/api/hello', (req, res) => {
  res.json({ message: 'Hello from Express backend!' });
});

// Serve frontend in production (if you build the frontend into ../frontend/dist)
const staticPath = path.join(__dirname, '..', 'frontend', 'dist');
app.use(express.static(staticPath));
app.get('*', (req, res) => {
  if (req.path.startsWith('/api')) return res.status(404).json({error:'Not found'});
  res.sendFile(path.join(staticPath, 'index.html'), err => {
    if (err) res.status(500).send('Build frontend or run frontend dev server.');
  });
});

app.listen(PORT, ()=> console.log(`Server listening on port ${PORT}`));
